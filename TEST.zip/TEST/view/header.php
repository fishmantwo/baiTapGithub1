<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="boxcenter">
        <!-- header -->
        <div class="row mb10 header">
            <h1>SHOP BÁN QUẦN ÁO</h1>
        </div>

        <!-- menu -->
        <div class="row mb menu">
            <ul>
                <li><a href="index.php?">Trang chủ</a></li>
                <li><a href="index.php?act=gioithieu">Giới thiệu</a></li>
                <li><a href="index.php?act=lienhe">Liên hệ</a></li>
                <li><a href="index.php?act=gopy">Góp ý</a></li>
                <li><a href="index.php?act=hoidap">Hỏi Đáp</a></li>
            </ul>
        </div>