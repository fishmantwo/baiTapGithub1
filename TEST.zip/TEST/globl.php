<?php
    $img_path = "uploads/";

?>